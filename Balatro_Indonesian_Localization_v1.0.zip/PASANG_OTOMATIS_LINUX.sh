#!/bin/bash
TARGET_DIR="$HOME/.steam/steam/steamapps/compatdata/2379780/pfx/drive_c/users/steamuser/AppData/Roaming/Balatro/localization"
mkdir -p "$TARGET_DIR"
cp -r localization/* "$TARGET_DIR/"
echo "Mod Bahasa Indonesia Balatro berhasil dipasang ke: $TARGET_DIR"
echo "Buka Balatro di Steam dan pilih Bahasa Indonesia di menu pengaturan!"
