@echo off
set "TARGET=%APPDATA%\Balatro\localization"
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /Y "localization\*" "%TARGET%\"
echo =======================================================
echo Mod Bahasa Indonesia Balatro Berhasil Terpasang!
echo Silakan buka game Balatro dan nikmati permainan.
echo =======================================================
pause
